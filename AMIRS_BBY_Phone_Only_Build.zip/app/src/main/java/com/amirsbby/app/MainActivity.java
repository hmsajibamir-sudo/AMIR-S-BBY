package com.amirsbby.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.widget.*;
import android.graphics.Color;
import android.view.*;
import android.net.Uri;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, messages;
    EditText input;
    TextToSpeech tts;
    static final int VOICE_REQ = 41, IMAGE_REQ = 42;
    final int green = Color.rgb(0,255,136);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        tts = new TextToSpeech(this, status -> {});
        buildUI();
    }
    void buildUI() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,18,18,12);
        root.setBackgroundColor(Color.rgb(5,8,7));
        setContentView(root);

        TextView title = new TextView(this);
        title.setText("AMIR’S BBY");
        title.setTextColor(green); title.setTextSize(26); title.setPadding(4,10,4,4);
        root.addView(title);
        TextView sub = new TextView(this);
        sub.setText("NEXT-GEN PERSONAL AI  •  ONLINE + OFFLINE");
        sub.setTextColor(Color.LTGRAY); sub.setTextSize(10);
        root.addView(sub);

        ScrollView scroll = new ScrollView(this);
        messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(4,14,4,14); scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        addMessage("AMIR’S BBY", "Welcome. আমি তোমার starter assistant। Voice input, speech output ও basic offline replies প্রস্তুত।");

        LinearLayout controls = new LinearLayout(this);
        input = new EditText(this);
        input.setSingleLine(false); input.setHint("Write in any supported language...");
        input.setHintTextColor(Color.GRAY); input.setTextColor(Color.WHITE);
        input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        controls.addView(input, new LinearLayout.LayoutParams(0,-2,1));
        Button send = button("SEND"); send.setOnClickListener(v -> sendMessage()); controls.addView(send);
        root.addView(controls);

        LinearLayout extras = new LinearLayout(this);
        Button mic = button("VOICE"); mic.setOnClickListener(v -> startVoice());
        Button theme = button("MY THEME"); theme.setOnClickListener(v -> pickImage());
        extras.addView(mic,new LinearLayout.LayoutParams(0,-2,1));
        extras.addView(theme,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(extras);
    }
    Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(green);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(15,28,22)));
        return b;
    }
    void addMessage(String who,String body) {
        TextView t = new TextView(this); t.setText(who+"\\n"+body);
        t.setTextColor(Color.WHITE); t.setTextSize(15); t.setPadding(12,12,12,12);
        t.setBackgroundColor(Color.rgb(15,24,19));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,7,0,7); messages.addView(t,p);
    }
    void sendMessage() {
        String q=input.getText().toString().trim(); if(q.isEmpty()) return;
        addMessage("YOU",q); input.setText("");
        String a=offlineReply(q); addMessage("AMIR’S BBY",a); speak(a);
    }
    String offlineReply(String q) {
        String s=q.toLowerCase(Locale.ROOT);
        if(s.contains("hello") || s.contains("হ্যালো") || s.contains("hi"))
            return "Hello! আমি AMIR’S BBY। এখন basic offline mode-এ আছি।";
        if(s.contains("তোমার নাম") || s.contains("your name"))
            return "আমার নাম AMIR’S BBY।";
        return "তোমার message পেয়েছি। এটি starter offline mode; উন্নত AI উত্তর, coding ও image generation-এর জন্য secure AI backend এবং model integration পরের ধাপে যোগ করতে হবে।";
    }
    void startVoice() {
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak to AMIR’S BBY");
        try { startActivityForResult(i,VOICE_REQ); }
        catch(Exception e) { addMessage("SYSTEM","এই ফোনে speech recognition service পাওয়া যায়নি।"); }
    }
    void pickImage() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,IMAGE_REQ);
    }
    @Override protected void onActivityResult(int r,int c,Intent d) {
        super.onActivityResult(r,c,d); if(c!=RESULT_OK || d==null) return;
        if(r==VOICE_REQ) {
            ArrayList<String> a=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if(a!=null&&!a.isEmpty()){input.setText(a.get(0));sendMessage();}
        } else if(r==IMAGE_REQ) {
            addMessage("SYSTEM","Theme image selected. Full wallpaper customization is planned for a later build.");
        }
    }
    void speak(String s) { if(tts!=null) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"bby"); }
    @Override public void onDestroy() {
        if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy();
    }
}
